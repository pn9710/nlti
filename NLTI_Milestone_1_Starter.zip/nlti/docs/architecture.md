# Architecture

The first release uses FastAPI for HTTP, SQLAlchemy for persistence, PostgreSQL as the intended database, and LangGraph to orchestrate matching. The matching calculation is deterministic and explainable; an LLM is not required to calculate a score.

Planned agent responsibilities:
- Procurement Scout: retrieve and normalize notices from permitted public sources.
- Tender Analyst: extract scope, deadlines, and stated requirements from tender documents.
- Opportunity Matcher: compare a contractor's own profile with public opportunity attributes.
- Cost Intelligence: later provide independent cost inputs to a contractor.
- Market Intelligence: later summarize public award and procurement history.
- Compliance Auditor: later identify missing or unverified tender-submission requirements.

The initial LangGraph only implements the matching node. Other agents will be added as separate nodes/subgraphs when their data contracts and safety controls are ready.

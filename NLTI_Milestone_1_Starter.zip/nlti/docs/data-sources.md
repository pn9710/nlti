# Procurement data sources

Before integrating a source, record:
- source owner and official URL;
- permitted access method and applicable terms;
- whether an API, feed, download, or manual entry is available;
- polling frequency and rate limits;
- fields collected and source timestamp;
- deduplication key and source reference;
- retention and correction process.

Do not bypass authentication, CAPTCHAs, rate limits, paywalls, or technical controls. Store the original notice URL and distinguish source facts from NLTI-generated analysis.

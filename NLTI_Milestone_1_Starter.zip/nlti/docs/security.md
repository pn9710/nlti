# Security baseline

- Never commit `.env`, credentials, API keys, private keys, or customer documents.
- Use HTTPS and managed secrets in hosted environments.
- Add authentication and role-based authorization before exposing contractor data to customers.
- Contractors must only access their own confidential profile and match results.
- Do not expose one contractor's private pricing, bid strategy, capacity details, or confidential documents to competitors.
- Treat all AI-extracted tender requirements as unverified until checked against the original procurement documents.

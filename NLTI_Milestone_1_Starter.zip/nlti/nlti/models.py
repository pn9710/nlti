from datetime import datetime, date, timezone
from sqlalchemy import String, Integer, Float, Boolean, Date, DateTime, ForeignKey, JSON, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from nlti.database import Base


def utcnow():
    return datetime.now(timezone.utc)


class Contractor(Base):
    __tablename__ = "contractors"

    id: Mapped[int] = mapped_column(primary_key=True)
    company_name: Mapped[str] = mapped_column(String(200), index=True)
    trades: Mapped[list] = mapped_column(JSON, default=list)
    regions: Mapped[list] = mapped_column(JSON, default=list)
    crew_capacity: Mapped[int | None] = mapped_column(Integer, nullable=True)
    equipment: Mapped[list] = mapped_column(JSON, default=list)
    certifications: Mapped[list] = mapped_column(JSON, default=list)
    insurance_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Tender(Base):
    __tablename__ = "tenders"

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(300), index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    location: Mapped[str] = mapped_column(String(200), index=True)
    region: Mapped[str] = mapped_column(String(100), index=True)
    trades: Mapped[list] = mapped_column(JSON, default=list)
    estimated_value: Mapped[float | None] = mapped_column(Float, nullable=True)
    closing_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    bid_security_required: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    mandatory_requirements: Mapped[list] = mapped_column(JSON, default=list)
    source_name: Mapped[str] = mapped_column(String(200), default="Unverified source")
    source_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    source_reference: Mapped[str | None] = mapped_column(String(200), nullable=True, unique=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class MatchRecord(Base):
    __tablename__ = "matches"

    id: Mapped[int] = mapped_column(primary_key=True)
    contractor_id: Mapped[int] = mapped_column(ForeignKey("contractors.id"), index=True)
    tender_id: Mapped[int] = mapped_column(ForeignKey("tenders.id"), index=True)
    score: Mapped[float] = mapped_column(Float)
    explanation: Mapped[list] = mapped_column(JSON, default=list)
    flags: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    contractor: Mapped[Contractor] = relationship()
    tender: Mapped[Tender] = relationship()

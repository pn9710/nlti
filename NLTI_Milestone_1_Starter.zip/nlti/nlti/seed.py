from datetime import date
from nlti.database import Base, engine, SessionLocal
from nlti.models import Contractor, Tender


def seed():
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        if db.query(Contractor).count() or db.query(Tender).count():
            print("Database already contains records; seed skipped.")
            return
        contractor = Contractor(
            company_name="DEMO — Labrador Building Services",
            trades=["roofing", "carpentry"],
            regions=["Labrador", "Happy Valley-Goose Bay"],
            crew_capacity=6,
            equipment=["scaffolding", "service truck"],
            certifications=[],
            insurance_verified=False,
        )
        tender = Tender(
            title="DEMO ONLY — Commercial roof replacement",
            description="Fictional example record for testing the matching workflow.",
            location="Happy Valley-Goose Bay",
            region="Labrador",
            trades=["roofing"],
            estimated_value=None,
            closing_date=date(2027, 1, 15),
            bid_security_required=True,
            mandatory_requirements=[],
            source_name="NLTI demonstration data — not a real procurement notice",
            source_url=None,
            source_reference="NLTI-DEMO-001",
            is_demo=True,
        )
        db.add_all([contractor, tender])
        db.commit()
        print("Inserted one fictional demo contractor and tender.")


if __name__ == "__main__":
    seed()

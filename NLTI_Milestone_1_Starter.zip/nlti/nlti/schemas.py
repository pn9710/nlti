from datetime import date
from pydantic import BaseModel, Field, HttpUrl, ConfigDict


class ContractorCreate(BaseModel):
    company_name: str = Field(min_length=2, max_length=200)
    trades: list[str] = []
    regions: list[str] = []
    crew_capacity: int | None = Field(default=None, ge=0)
    equipment: list[str] = []
    certifications: list[str] = []
    insurance_verified: bool = False


class ContractorOut(ContractorCreate):
    id: int
    model_config = ConfigDict(from_attributes=True)


class TenderCreate(BaseModel):
    title: str = Field(min_length=3, max_length=300)
    description: str = ""
    location: str
    region: str
    trades: list[str] = []
    estimated_value: float | None = Field(default=None, ge=0)
    closing_date: date | None = None
    bid_security_required: bool | None = None
    mandatory_requirements: list[str] = []
    source_name: str = "Manually entered"
    source_url: str | None = None
    source_reference: str | None = None
    is_demo: bool = False


class TenderOut(TenderCreate):
    id: int
    is_active: bool
    model_config = ConfigDict(from_attributes=True)


class MatchOut(BaseModel):
    tender_id: int
    tender_title: str
    score: float
    explanation: list[str]
    flags: list[str]

from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
from nlti.database import Base, engine, get_db
from nlti.models import Contractor, Tender, MatchRecord
from nlti.schemas import ContractorCreate, ContractorOut, TenderCreate, TenderOut, MatchOut
from nlti.agents.graph import matching_graph

app = FastAPI(
    title="NLTI API",
    description="Newfoundland & Labrador Tender Intelligence — initial discovery and matching API.",
    version="0.1.0",
)


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)


@app.get("/health")
def health():
    return {"status": "ok", "service": "NLTI API", "version": "0.1.0"}


@app.get("/tenders", response_model=list[TenderOut])
def list_tenders(region: str | None = None, trade: str | None = None, db: Session = Depends(get_db)):
    query = select(Tender).where(Tender.is_active.is_(True))
    if region:
        query = query.where(Tender.region.ilike(f"%{region}%"))
    rows = db.scalars(query.order_by(Tender.closing_date.asc().nullslast())).all()
    if trade:
        wanted = trade.casefold()
        rows = [row for row in rows if wanted in {x.casefold() for x in (row.trades or [])}]
    return rows


@app.post("/tenders", response_model=TenderOut, status_code=201)
def create_tender(payload: TenderCreate, db: Session = Depends(get_db)):
    if payload.source_reference:
        existing = db.scalar(select(Tender).where(Tender.source_reference == payload.source_reference))
        if existing:
            raise HTTPException(status_code=409, detail="Tender source_reference already exists.")
    tender = Tender(**payload.model_dump())
    db.add(tender)
    db.commit()
    db.refresh(tender)
    return tender


@app.get("/contractors", response_model=list[ContractorOut])
def list_contractors(db: Session = Depends(get_db)):
    return db.scalars(select(Contractor).order_by(Contractor.company_name)).all()


@app.post("/contractors", response_model=ContractorOut, status_code=201)
def create_contractor(payload: ContractorCreate, db: Session = Depends(get_db)):
    contractor = Contractor(**payload.model_dump())
    db.add(contractor)
    db.commit()
    db.refresh(contractor)
    return contractor


@app.post("/matches/{contractor_id}", response_model=list[MatchOut])
def match_contractor(contractor_id: int, db: Session = Depends(get_db)):
    contractor = db.get(Contractor, contractor_id)
    if contractor is None:
        raise HTTPException(status_code=404, detail="Contractor not found.")
    tenders = db.scalars(select(Tender).where(Tender.is_active.is_(True))).all()
    output = matching_graph.invoke({"contractor": contractor, "tenders": tenders})
    for item in output["results"]:
        db.add(MatchRecord(
            contractor_id=contractor.id,
            tender_id=item["tender_id"],
            score=item["score"],
            explanation=item["explanation"],
            flags=item["flags"],
        ))
    db.commit()
    return output["results"]

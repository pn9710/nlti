# NLTI — Newfoundland & Labrador Tender Intelligence

Initial milestone: tender records, contractor profiles, transparent matching, and a LangGraph workflow scaffold.

## What this release does
- FastAPI API for tenders, contractors, and matches.
- SQLAlchemy database models.
- Deterministic, explainable contractor-to-tender matching.
- LangGraph workflow that runs the matching step.
- Demo seed data clearly marked as fictional.
- Tests for matching logic.

## What it does not do yet
- It does not scrape procurement websites automatically.
- It does not verify licences, insurance, bid security, or contractor capacity.
- It does not estimate a bid price or predict/guarantee awards.
- It does not coordinate bids or share confidential pricing between competing contractors.

## Quick start (browser workspace or computer)

1. Create a PostgreSQL database.
2. Copy `.env.example` to `.env` and set `DATABASE_URL`.
3. Install dependencies:

   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -e ".[dev]"
   ```

4. Create tables:

   ```bash
   python -m nlti.seed
   ```

   The seed command creates tables and inserts clearly labelled demonstration records.

5. Start the API:

   ```bash
   uvicorn nlti.api.main:app --reload
   ```

6. Open `/docs` on the running server to try the API.

For local SQLite smoke tests, set:
`DATABASE_URL=sqlite:///./nlti.db`

PostgreSQL is the intended persistent database. pgvector is included as a dependency for a later semantic retrieval milestone; this first release does not require vector queries.

## API endpoints
- `GET /health`
- `GET /tenders`
- `POST /tenders`
- `GET /contractors`
- `POST /contractors`
- `POST /matches/{contractor_id}` — match one contractor against active tenders.

## GitHub upload from iPhone
1. Download and extract the project ZIP in the iPhone Files app.
2. Open the private `nlti` repository in Safari.
3. Choose **Add file → Upload files**.
4. Upload the contents of the extracted `nlti` folder (including hidden files if your interface offers them; `.env` is not included).
5. Commit to the `main` branch with message: `Initial NLTI backend and matching MVP`.

If GitHub's mobile upload interface does not accept a folder, upload the files in batches while preserving their folder paths, or use GitHub's web editor to create the files. Do not upload `.env`, passwords, API keys, or database credentials.

## Data-source policy
Add procurement sources only after reviewing their terms, access rules, update methods, and permitted reuse. Preserve source URLs and retrieval timestamps. Do not bypass logins, CAPTCHAs, rate limits, or technical access controls.

## Matching policy
Scores are screening aids, not eligibility decisions. Mandatory requirements must be checked separately. Contractors receive recommendations based on their own profiles and public tender information. NLTI must not coordinate competing bids, exchange confidential bid strategies, allocate projects, or promise awards.
